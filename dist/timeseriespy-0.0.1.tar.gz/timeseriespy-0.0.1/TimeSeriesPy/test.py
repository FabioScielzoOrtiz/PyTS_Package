def mytest():
    print('just a test')